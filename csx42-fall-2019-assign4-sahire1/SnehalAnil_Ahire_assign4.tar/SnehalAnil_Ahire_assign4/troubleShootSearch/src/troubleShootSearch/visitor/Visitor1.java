package troubleShootSearch.visitor;
import troubleShootSearch.Structure.Tree;
import troubleShootSearch.Structure.Arrlist;
import java.util.ArrayList; 
public interface Visitor1
{
public void visit1(Arrlist A_Object,String j);
//public void visit(Tree T_Object);

}
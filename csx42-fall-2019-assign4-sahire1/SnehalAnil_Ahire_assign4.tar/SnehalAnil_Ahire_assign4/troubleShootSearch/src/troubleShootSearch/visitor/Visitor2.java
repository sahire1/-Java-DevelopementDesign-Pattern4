package troubleShootSearch.visitor;
import troubleShootSearch.Structure.Tree;
import troubleShootSearch.Structure.Arrlist;
import java.util.ArrayList; 
public interface Visitor2
{
public int visit(Tree T_Object,String j);


}